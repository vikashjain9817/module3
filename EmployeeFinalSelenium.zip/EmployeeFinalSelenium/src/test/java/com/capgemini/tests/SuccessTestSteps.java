package com.capgemini.tests;

import static org.junit.Assert.assertTrue;

import com.capgemini.base.TestBase;
import com.capgemini.pages.Employee;
import com.capgemini.pages.NextStep;
import com.capgemini.pages.Success;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SuccessTestSteps extends TestBase{
	
	static Employee employee;
	static NextStep nextStep;
	static Success success;
	
	public SuccessTestSteps(){
		super();
		setUp();
	}
	
	public static void setUp(){
		initialization();
		nextStep = new NextStep(); 
		success = new Success();
	}
	
	
	
	@Given("^The Successfully page is opening$")
	public void sucessfullyPage() throws Throwable {
		
	}

	@When("^The successfully page is open$")
	public void sucessfullyPageOpen() throws Throwable {
		
	}

	@Then("^then image will be displayed$")
	public void validateSucessfullyPage() throws Throwable {
		employee = new Employee(); 
		employee.setCity("pune");
		employee.setId("1001");
		employee.setName("vikash");
		employee.setState("maha");
		employee.gotoNextPage();
		Thread.sleep(5000);
		nextStep.setLanguage("java");
		nextStep.setProjectName("Selenium Project");
		nextStep.submit();
		Thread.sleep(5000);
		assertTrue(success.validateImage());
		driver.quit();
	}



}
