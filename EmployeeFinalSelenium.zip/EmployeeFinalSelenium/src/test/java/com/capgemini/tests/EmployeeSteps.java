package com.capgemini.tests;

import static org.junit.Assert.assertEquals;

import com.capgemini.base.TestBase;
import com.capgemini.pages.Employee;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EmployeeSteps extends TestBase{
	
	static Employee employee;
	
	public EmployeeSteps(){
		super();
		setUp();
	}
	
	public static void setUp(){
		initialization();
	}

	@Given("^The employee page is opening$")
	public void employeePage() throws Throwable {
		
	}

	@When("^The employee page is open$")
	public void employeePageOpen() throws Throwable {
		
	}

	@Then("^then the title must be (.*)$")
	public void validateEmployeePage(String name) throws Throwable {
		employee = new Employee(); 
		String title = employee.getTitle();
		assertEquals(name, title);
		driver.quit();
	}

}
