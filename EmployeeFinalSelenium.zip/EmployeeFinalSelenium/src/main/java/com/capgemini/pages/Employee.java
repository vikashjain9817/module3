package com.capgemini.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.capgemini.base.TestBase;

public class Employee extends TestBase {
	
	@FindBy(xpath = "//*[@id=\"div1\"]/form/input[1]")
	WebElement id;
	
	@FindBy(xpath = "//*[@id=\"fname\"]")
	WebElement name;
	
	@FindBy(xpath = "//*[@id=\"div1\"]/form/input[3]")
	WebElement state;
	
	@FindBy(xpath = "//*[@id=\"div1\"]/form/select")
	private List<WebElement> city;
	
	@FindBy(xpath = "//*[@id=\"next\"]")
	WebElement nextStep;

	
	//Initializing the Page Objects:
	public Employee(){
			PageFactory.initElements(driver, this);
	}
	
	/*
	 * getters and setters.
	 */
	public String getId() {
		return id.getAttribute("value");
	}

	public void setId(String id) {
		this.id.sendKeys(id);
	}

	public String getName() {
		return name.getAttribute("value");
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public String getState() {
		return state.getAttribute("value");
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public String getCity() {
		for (WebElement webElement : city) 
			if(webElement.isSelected())
				return webElement.getAttribute("value");
			return null;
	}

	public void setCity(String city) {
		if(city.equals("pune"))
			this.city.get(0).click();
		else if(city.equals("mumbai"))
			this.city.get(1).click();
	}

	public String getTitle() {
		return driver.getTitle();
	}
	
	public void gotoNextPage()
	{
		nextStep.click();
	}
}
