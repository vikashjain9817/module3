package com.capgemini.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.capgemini.base.TestBase;

public class NextStep extends TestBase{
	
	@FindBy(name = "projectName")
	WebElement pName;
	
	@FindBy(name = "java")
	WebElement java;
	
	@FindBy(name = "python")
	WebElement python;
	
	@FindBy(name = "c#")
	WebElement c;
	
	@FindBy(xpath = "//*[@id=\"div1\"]/form/input[5]")
	WebElement sub;
	
	
	public NextStep() {
		PageFactory.initElements(driver, this);
	}
	
	public String getprojectName() {
		return pName.getAttribute("value");
	}

	public void setProjectName(String pName) {
		this.pName.sendKeys(pName);
	}
	
	public String getLanguage()
	{
		if(java.isSelected())
			return java.getAttribute("value");
		if(python.isSelected())
			return python.getAttribute("value");
		if(c.isSelected())
			return c.getAttribute("value");
		return null;
	}
	
	public void setLanguage(String name) {
		if(name.equals("java"))
			this.java.click();
		if(name.equals("python"))
			this.python.click();
		if(name.equals("c#"))
			this.c.click();
	}

	public String getTitle() {
		
		return driver.getTitle();
	}
	
	public void submit() {
		sub.click();
		
	}
}
