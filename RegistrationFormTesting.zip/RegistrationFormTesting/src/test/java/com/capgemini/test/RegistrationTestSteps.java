package com.capgemini.test;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;

import com.capgemini.base.TestBaseDriver;
import com.capgemini.pages.RegistrationForm;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationTestSteps extends TestBaseDriver{
	
	static RegistrationForm registrationForm;
	
	public RegistrationTestSteps(){
		super();
		setUp();
	}
	
	public static void setUp(){
		initialization();
		registrationForm = new RegistrationForm();
	}
	
	@Given("^The registrationPage is opening$")
	public void employeePage() throws Throwable {
		
	}

	@When("^The registrationPage  is open$")
	public void employeePageOpen() throws Throwable {
		
	}

	@Then("^then the title must be (.*)$")
	public void validateEmployeePage(String name) throws Throwable {
		String title = registrationForm.getTitle();
		assertEquals(name, title);
		Thread.sleep(2000);
		driver.quit();
	}
	
	@Given("^The registrationPage is open$")
	public void the_registrationPage_is_open() throws Throwable {
	}

	@When("^leave the userid field empty and click submit$")
	public void leave_the_userid_field_empty_and_click_submit() throws Throwable {
		registrationForm.setUserId(""); Thread.sleep(1000);
		registrationForm.setSub();
		Thread.sleep(2000);
	}
	
	@Then("^then the alert box displayed$")
	public void then_the_alert_box_displayed() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String text = alert.getText();
		System.out.println("Alert: " +text);
		driver.quit();
	}
	
	@When("^leave the password field empty and click submit$")
	public void leave_the_password_field_empty_and_click_submit() throws Throwable {
		registrationForm.setUserId("vikash"); Thread.sleep(1000); 
		registrationForm.setPwd(""); Thread.sleep(1000);
		registrationForm.setSub();
		Thread.sleep(2000);
	}
	
	@When("^enter number in name field and click submit$")
	public void enter_number_in_name_field_and_click_submit() throws Throwable {
		registrationForm.setUserId("vikash"); Thread.sleep(1000); 
		registrationForm.setPwd("vikash12"); Thread.sleep(1000); 
		registrationForm.setName("123"); Thread.sleep(1000);
		registrationForm.setSub();
		Thread.sleep(2000);
	}
	
	

}
