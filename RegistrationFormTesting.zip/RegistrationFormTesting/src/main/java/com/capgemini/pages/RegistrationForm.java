package com.capgemini.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.capgemini.base.TestBaseDriver;

public class RegistrationForm extends TestBaseDriver{

	public RegistrationForm() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//*[@id=\"usrID\"]")
	WebElement userId;
	
	@FindBy(xpath = "//*[@id=\"pwd\"]")
	WebElement pwd;
	
	@FindBy(xpath = "//*[@id=\"usrname\"]")
	WebElement name;
	
	@FindBy(xpath = "//*[@id=\"addr\"]")
	WebElement add;
	
	@FindBy(xpath = "/html/body/form/ul/li[10]/select")
	WebElement country;
	
	@FindBy(xpath = "/html/body/form/ul/li[12]/input")
	WebElement code;
	
	@FindBy(xpath = "/html/body/form/ul/li[14]/input")
	WebElement email;
	
	@FindBy(xpath = "/html/body/form/ul/li[16]/input")
	WebElement male;
	
	@FindBy(xpath = "/html/body/form/ul/li[17]/input")
	WebElement female;
	
	@FindBy(xpath = "/html/body/form/ul/li[19]/input")
	WebElement english;
	
	@FindBy(xpath = "/html/body/form/ul/li[20]/input")
	WebElement nonEnglish;
	
	
	@FindBy(xpath = "//*[@id=\"desc\"]")
	WebElement about;
	
	@FindBy(xpath = "/html/body/form/ul/li[23]/input")
	WebElement sub;

	public WebElement getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId.sendKeys(userId);
	}

	public WebElement getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd.sendKeys(pwd);
	}

	public WebElement getName() {
		return name;
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public WebElement getAdd() {
		return add;
	}

	public void setAdd(String add) {
		this.add.sendKeys(add);
	}

	public WebElement getCountry() {
		return country;
	}

	public void setCountry(String country) {
		Select countrySelect = new Select(this.country);
		countrySelect.selectByVisibleText(country);
	}

	public WebElement getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code.sendKeys(code);
	}

	public WebElement getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMale() {
		return this.male;
	}

	public void setMale(String male) {
		this.male.sendKeys(male);
	}

	public WebElement getFemale() {
		return this.female;
	}

	public void setFemale(String female) {
		this.female.sendKeys(female);
	}

	public WebElement getEnglish() {
		return this.english;
	}

	public void setEnglish(String english) {
		this.english.sendKeys(english);;
	}

	public WebElement getNonEnglish() {
		return this.nonEnglish;
	}

	public void setNonEnglish(String nonEnglish) {
		this.nonEnglish.sendKeys(nonEnglish);
	}

	public WebElement getAbout() {
		return this.about;
	}

	public void setAbout(String about) {
		this.about.sendKeys(about);
	}
	
	public void setSub() {
		this.sub.click();
	}

	public String getTitle() {
		// TODO Auto-generated method stub
		return driver.getTitle();
	}
}
