package com.cap.tests;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import com.cap.base.TestBase;
import com.cap.pages.HotelBookingFactory;
import com.cap.pages.LoginPageFactory;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelBookingTest extends TestBase{
	
	static LoginPageFactory login;
	static HotelBookingFactory hotel;
	
	public HotelBookingTest(){
		super();
		setUp();
	}
	
	public static void setUp(){
		initialization();
		login = new LoginPageFactory();
		hotel = new HotelBookingFactory();
	}
	
	
	
	@Given("^user is on booking page$")
	public void booking_Page() {
		
		
	}
	
	@When("^user enters all valid data to nevigate booking page$")
	public void user_enters_all_valid_data_booking() throws Throwable {
			
	}
	
	@Then("^check the title of the booking page$")
	public void validate_title_booking_page() throws InterruptedException {
		login.setPfuname("capgemini"); Thread.sleep(1000);
		login.setPfpwd("capg1234"); Thread.sleep(1000);
		login.setPfbutton();
		Thread.sleep(2000);
		String title = hotel.getTitle();
		assertEquals("booking page", title);
		driver.quit();
	}
	
	@Given("^User is on hotel booking page$")
	public void user_is_on_hotel_booking_page() throws Throwable {
	    
	}

	@When("^user enters all valid data $")
	public void all_data_given_valid() throws InterruptedException {
		login.setPfuname("capgemini"); Thread.sleep(1000);
		login.setPfpwd("capg1234"); Thread.sleep(1000);
		login.setPfbutton();
		hotel.setPffname("Rutuja");	Thread.sleep(1000);
		hotel.setPflname("Kulkarni");	Thread.sleep(1000);
		hotel.setPfemail("rutukulkarni2003@yahoo.com");	Thread.sleep(1000);
		hotel.setPfmobile("7722005480");	Thread.sleep(1000);
		hotel.setPfcity("Pune");	Thread.sleep(1000);
		hotel.setPfstate("Maharashtra");	Thread.sleep(1000);
		hotel.setPfpersons(5);	Thread.sleep(1000);
		hotel.setPfcardholder("Rutuja Kulkarni");	Thread.sleep(1000);
		hotel.setPfdebit("5678567867897890");	Thread.sleep(1000);
		hotel.setPfcvv("067");	Thread.sleep(1000);
		hotel.setPfmonth("5");	Thread.sleep(1000);
		hotel.setPfyear("2020"); 
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		hotel.setPfbutton();
	}
	@Then("^navigate to welcome page$")
	public void navigate_to_welcome_page() throws Throwable {
		driver.navigate().to("C:\\Users\\vikas\\Desktop\\success.html");
		driver.quit();
	}

	@When("^user leaves first Name blank$")
	public void user_leaves_first_Name_blank() throws Throwable {
		login.setPfuname("capgemini"); Thread.sleep(1000);
		login.setPfpwd("capg1234"); Thread.sleep(1000);
		login.setPfbutton();
		Thread.sleep(2000);
	    hotel.setPffname(""); Thread.sleep(1000);
	}

	@When("^clicks the button$")
	public void clicks_the_button() throws Throwable {
	    hotel.setPfbutton(); Thread.sleep(2000);
	}
	
	@Then("^display alert msg of first name empty$")
	public void display_alert_msg() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	    driver.quit();
	}
	
	@When("^user leaves last Name blank and clicks the button$")
	public void user_leaves_last_Name_blank_and_clicks_the_button() throws Throwable {
		login.setPfuname("capgemini"); Thread.sleep(1000);
		login.setPfpwd("capg1234"); Thread.sleep(1000);
		login.setPfbutton();
		hotel.setPffname("vikash");
		hotel.setPflname("");
		hotel.setPfbutton();
		Thread.sleep(2000);
	}

	@Then("^display alert msg leaving the last Name blank$")
	public void display_alert_msg_leaving_the_last_Name_blank() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	    driver.quit();
	}

	@When("^user enters all data$")
	public void user_enters_all_data() throws Throwable {
		login.setPfuname("capgemini"); Thread.sleep(1000);
		login.setPfpwd("capg1234"); Thread.sleep(1000);
		login.setPfbutton();
		hotel.setPffname("Rutuja");	Thread.sleep(1000);
		hotel.setPflname("Kulkarni");	Thread.sleep(1000);
		hotel.setPfmobile("7722005480");	Thread.sleep(1000);
		hotel.setPfcity("Pune");	Thread.sleep(1000);
		hotel.setPfstate("Maharashtra");	Thread.sleep(1000);
		hotel.setPfpersons(5);	Thread.sleep(1000);
		hotel.setPfcardholder("Rutuja Kulkarni");	Thread.sleep(1000);
		hotel.setPfdebit("5671234567899876");	Thread.sleep(1000);
		hotel.setPfcvv("056");	Thread.sleep(1000);
		hotel.setPfmonth("9");	Thread.sleep(1000);
		hotel.setPfyear("2020");	Thread.sleep(1000);
	}

	@When("^user enters incorrect email format and clicks the button$")
	public void user_enters_incorrect_email_format_and_clicks_the_button() throws Throwable {
		hotel.setPfemail("Rk2@.com");	Thread.sleep(1000);
		hotel.setPfbutton();
	}

	@Then("^display alert msg incorrect email format$")
	public void display_alert_msg_incorrect_email_format() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	    driver.quit();
	}

	@When("^user leaves MobileNo blank and clicks the button$")
	public void user_leaves_MobileNo_blank_and_clicks_the_button() throws Throwable {
		login.setPfuname("capgemini"); Thread.sleep(1000);
		login.setPfpwd("capg1234"); Thread.sleep(1000);
		login.setPfbutton();
		hotel.setPffname("Rutuja");	Thread.sleep(1000);
		hotel.setPflname("Kulkarni");	Thread.sleep(1000);
		hotel.setPfemail("rutuja.k@gmail.com");	Thread.sleep(1000);
		hotel.setPfmobile("");	Thread.sleep(1000);
		hotel.setPfbutton();
	}

	@Then("^display alert msg leaving the mobile no\\. blank$")
	public void display_alert_msg_leaving_the_mobile_no_blank() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	    driver.quit();
	}
	@When("^user enters incorrect mobileNo format and clicks the button$")
	public void user_enters_incorrect_mobileNo_format_and_clicks_the_button(DataTable arg1) throws Throwable {
		login.setPfuname("capgemini"); Thread.sleep(1000);
		login.setPfpwd("capg1234"); Thread.sleep(1000);
		login.setPfbutton();
		hotel.setPffname("Rutuja");	Thread.sleep(1000);
		hotel.setPflname("Kulkarni");	Thread.sleep(1000);
		hotel.setPfemail("rutuja.k@gmail.com");	Thread.sleep(1000);
				
		List<String> objList = arg1.asList(String.class);
		//hotel.setPfmobile(objList);	Thread.sleep(1000);
		hotel.setPfbutton();
		
		for(int i=0; i<objList.size(); i++) {
			if(Pattern.matches("^[7-9]{1}[0-9]{9}$", objList.get(i))) {
			System.out.println("***** Matched" + objList.get(i) + "*****");
			}
			else {
				System.out.println("***** NOT Matched" + objList.get(i) + "*****");
			}
		}
	}
	
	@Then("^display alert msg incorrect mobileNo format$")
	public void display_alert_msg_incorrect_mobileNo_format() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	    driver.quit();
	}

	
	@When("^user doesnot select city$")
	public void user_doesnot_select_city() throws Throwable {
		login.setPfuname("capgemini"); Thread.sleep(1000);
		login.setPfpwd("capg1234"); Thread.sleep(1000);
		login.setPfbutton();
		hotel.setPffname("Rutuja");	Thread.sleep(1000);
		hotel.setPflname("Kulkarni");	Thread.sleep(1000);
		hotel.setPfemail("rutuja.k@gmail.com");	Thread.sleep(1000);
		hotel.setPfmobile("7722005480");	Thread.sleep(1000);
		hotel.setPfcity("Select City");	Thread.sleep(1000);
		hotel.setPfbutton();
	}
	
	@Then("^display alert msg not select city$")
	public void display_alert_msg_not_select_city() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	    driver.quit();
	}
}
