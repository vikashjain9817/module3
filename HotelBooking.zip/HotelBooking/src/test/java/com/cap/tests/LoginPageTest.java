package com.cap.tests;


import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import com.cap.base.TestBase;
import com.cap.pages.LoginPageFactory;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class LoginPageTest extends TestBase{
	private LoginPageFactory log;
	
	public LoginPageTest(){
		super();
		setUp();
	}
	
	public static void setUp(){
		initialization();
	}
	
	@Given("^User is on hotel booking application$")
	public void user_is_on_hotel_booking_application() throws Throwable {
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		log = new LoginPageFactory();
		String title = log.getTitle();
		assertEquals(title, "loginpage");
		driver.quit();
	}

	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
			log = new LoginPageFactory();
			log.setPfuname("capgemini"); Thread.sleep(1000);
			log.setPfpwd("capg1234"); Thread.sleep(1000);
			log.setPfbutton();
	}

	@Then("^navigate to hotel booking page$")
	public void loginSuccessfully() throws Throwable {
		driver.navigate().to("C:\\Users\\vikas\\Desktop\\hotelbooking.html");
		driver.quit();
	}

	@When("^user leaves UserName blank and clicks the button$")
	public void user_leaves_UserName_blank_and_clicks_the_button() throws Throwable {
		log = new LoginPageFactory();
		log.setPfuname(""); Thread.sleep(1000);
		log.setPfpwd("capg1234"); Thread.sleep(1000);
		log.setPfbutton();
	}
	// here we catch error like this because it is coming in error msg not in popup alert box 
	//and when this situation is there you have to make different alert then for every situation
	@Then("^display ualert msg$")
	public void display_alert_msg() throws Throwable {
		String alertMessage = driver.findElement(By.id("userErrMsg")).getText();
		Thread.sleep(1000);
	    System.out.println("******" + alertMessage);
	    driver.quit();
	}

	@When("^user leaves password blank and clicks the button$")
	public void user_leaves_password_blank_and_clicks_the_button() throws Throwable {
		log = new LoginPageFactory();
		log.setPfuname("capgemini"); Thread.sleep(1000);
		log.setPfpwd(""); Thread.sleep(1000);
		log.setPfbutton();
	}
	// here we catch error like this because it is coming in error msg not in popup alert box 
	@Then("^display palert msg$")
	public void display_palert_msg() throws Throwable {
		String alertMessage = driver.findElement(By.id("pwdErrMsg")).getText();
		Thread.sleep(1000);
	    System.out.println("******" + alertMessage);
	    driver.quit();
	}

	@When("^user enter wrong username and password and clicks the button$")
	public void user_enter_wrong_username_and_password_and_clicks_the_button() throws Throwable {
		log = new LoginPageFactory();
		log.setPfuname("capge"); Thread.sleep(1000);
		log.setPfpwd("capg12"); Thread.sleep(1000);
		log.setPfbutton();
	}
	
	@Then("^display alert msg$")
	public void display_alert_msg1() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	    driver.quit();
	}


}
